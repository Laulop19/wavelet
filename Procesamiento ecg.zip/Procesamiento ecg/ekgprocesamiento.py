import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import butter, filtfilt, find_peaks
import pywt

# ====================================
# Carga de la señal ECG
# ====================================
with open('datos.txt') as f:
    data = [line for line in f if line.strip()]  # Ignora líneas vacías
    ekg_signal = np.array(data, dtype=float)

# Parámetros de la señal
fs = 1000  # Frecuencia de muestreo en Hz
num_samples = len(ekg_signal)
max_time = num_samples / fs
print(f"Tiempo máximo de la señal: {max_time:.2f} segundos")

# ====================================
# Funciones de procesamiento de señal
# ====================================
def butter_bandpass(lowcut, highcut, fs, order=4):
    nyquist = 0.5 * fs
    low = lowcut / nyquist
    high = highcut / nyquist
    b, a = butter(order, [low, high], btype='band')
    return b, a

def apply_filter(data, lowcut, highcut, fs):
    b, a = butter_bandpass(lowcut, highcut, fs, order=4)
    return filtfilt(b, a, data)

def detect_r_peaks(signal, fs):
    mean_filtered = np.mean(signal)
    std_filtered = np.std(signal)
    min_height = mean_filtered + 1.5 * std_filtered  # Umbral para picos R

    peaks, _ = find_peaks(signal, height=min_height, distance=fs * 0.6)
    filtered_peaks = []

    # Corregir la condición para verificar los picos R
    for peak in peaks:
        if signal[peak] == np.max(signal[max(0, peak - 10):min(num_samples, peak + 10)]):
            filtered_peaks.append(peak)

    return np.array(filtered_peaks)

# ====================================
# Procesamiento de señal: 5 minutos
# ====================================
filtered_ekg_full = apply_filter(ekg_signal, 0.5, 100.0, fs)
peaks_full = detect_r_peaks(filtered_ekg_full, fs)

# Intervalos R-R para la señal completa
r_r_intervals_full = np.diff(peaks_full) / fs * 1000  # en ms
mean_rr_full = np.mean(r_r_intervals_full) if len(r_r_intervals_full) > 0 else 0
std_rr_full = np.std(r_r_intervals_full) if len(r_r_intervals_full) > 0 else 0

print(f"Media de los intervalos R-R (5 minutos): {mean_rr_full:.2f} ms")
print(f"Desviación estándar de los intervalos R-R (5 minutos): {std_rr_full:.2f} ms")

# Crear vector de tiempo para la señal completa
t_full = np.arange(0, num_samples) / fs

# ====================================
# Transformada wavelet de Morlet para toda la señal
# ====================================
frequencies = np.arange(1, 101, 1)  # Ajustar a 100 Hz
wavelet_name = 'cmor'  # Wavelet de Morlet

# Aplicar la transformada wavelet a la señal completa
coefficients_full, frequencies_full = pywt.cwt(filtered_ekg_full, frequencies, wavelet_name, sampling_period=1/fs)

# ====================================
# Visualización
# ====================================
# Gráfica 1: Señal ECG Original
plt.figure(figsize=(12, 6))
plt.plot(t_full, ekg_signal, label='Señal ECG Original', color='lightgray')
plt.title('Señal ECG Original (5 minutos)')
plt.xlabel('Tiempo [s]')
plt.ylabel('Amplitud')
plt.legend()
plt.show()

# Gráfica 2: Señal ECG Filtrada
plt.figure(figsize=(12, 6))
plt.plot(t_full, filtered_ekg_full, label='Señal ECG Filtrada (0.5 - 100 Hz)', color='orange')
plt.title('Señal ECG Filtrada (5 minutos)')
plt.xlabel('Tiempo [s]')
plt.ylabel('Amplitud')
plt.legend()
plt.show()

# Gráfica 3: Señal Filtrada con Picos R
plt.figure(figsize=(12, 6))
plt.plot(t_full, filtered_ekg_full, label='Señal ECG Filtrada', color='orange')
plt.plot(t_full[peaks_full], filtered_ekg_full[peaks_full], 'rx', label='Picos R')
plt.title('Señal ECG Filtrada con Picos R (5 minutos)')
plt.xlabel('Tiempo [s]')
plt.ylabel('Amplitud')
plt.legend()
plt.show()

# Gráfica 4: Transformada Wavelet
plt.figure(figsize=(12, 6))
plt.imshow(np.abs(coefficients_full), aspect='auto', extent=[0, max_time, frequencies_full[-1], frequencies_full[0]], cmap='jet')
plt.colorbar(label='Magnitude')
plt.ylabel('Frequency (Hz)')
plt.xlabel('Time (s)')
plt.title('Transformada Wavelet de Morlet (Todo el EKG)')
plt.ylim(0, 100)  # Limitar el eje Y a 100 Hz
plt.tight_layout()
plt.show()

# ====================================
# Transformada wavelet de Morlet para 30 segundos
# ====================================
time_limit = 30  # Tiempo en segundos
samples_limit = int(time_limit * fs)

if samples_limit > len(filtered_ekg_full):
    samples_limit = len(filtered_ekg_full)  # Ajustar si hay menos datos disponibles

data_segment = ekg_signal[:samples_limit]
filtered_segment = filtered_ekg_full[:samples_limit]
peaks_segment = detect_r_peaks(filtered_segment, fs)  # Detectar picos en el segmento

# Aplicar la transformada wavelet a la segmentación de 30 segundos
coefficients_segment, frequencies_segment = pywt.cwt(filtered_segment, frequencies, wavelet_name, sampling_period=1/fs)

# Gráfica 5: Señal ECG Original de 30 segundos
plt.figure(figsize=(12, 6))
t_segment = np.arange(0, samples_limit) / fs
plt.plot(t_segment, data_segment, label='Señal ECG Original (30 s)', color='lightgray')
plt.title('Señal ECG Original (30 segundos)')
plt.xlabel('Tiempo [s]')
plt.ylabel('Amplitud')
plt.legend()
plt.show()

# Gráfica 6: Señal ECG Filtrada de 30 segundos
plt.figure(figsize=(12, 6))
plt.plot(t_segment, filtered_segment, label='Señal ECG Filtrada (0.5 - 100 Hz)', color='orange')
plt.title('Señal ECG Filtrada (30 segundos)')
plt.xlabel('Tiempo [s]')
plt.ylabel('Amplitud')
plt.legend()
plt.show()

# Gráfica 7: Señal Filtrada con Picos R (30 segundos)
plt.figure(figsize=(12, 6))
plt.plot(t_segment, filtered_segment, label='Señal ECG Filtrada', color='orange')
plt.plot(t_segment[peaks_segment], filtered_segment[peaks_segment], 'rx', label='Picos R')
plt.title('Señal ECG Filtrada con Picos R (30 segundos)')
plt.xlabel('Tiempo [s]')
plt.ylabel('Amplitud')
plt.legend()
plt.show()

# Gráfica 8: Transformada Wavelet para 30 segundos
plt.figure(figsize=(10, 6))
plt.imshow(np.abs(coefficients_segment), aspect='auto', extent=[0, time_limit, frequencies_segment[-1], frequencies_segment[0]], cmap='jet')
plt.colorbar(label='Magnitude')
plt.ylabel('Frequency (Hz)')
plt.xlabel('Time (s)')
plt.title('Transformada Wavelet de Morlet (30 segundos)')
plt.ylim(0, 100)  # Limitar el eje Y a 100 Hz
plt.tight_layout()
plt.show()

# ====================================
# Graficar intervalos R-R
# ====================================
# Gráfica 9: Intervalos R-R (5 minutos)
plt.figure(figsize=(12, 6))
plt.plot(r_r_intervals_full, label='Intervalos R-R', color='blue')
plt.title('Intervalos R-R (5 minutos)')
plt.xlabel('Número de intervalo')
plt.ylabel('Intervalo R-R (ms)')
plt.legend()
plt.grid()
plt.show()

# Gráfica 10: Intervalos R-R (30 segundos)
r_r_intervals_segment = np.diff(peaks_segment) / fs * 1000  # en ms
mean_rr_segment = np.mean(r_r_intervals_segment) if len(r_r_intervals_segment) > 0 else 0
std_rr_segment = np.std(r_r_intervals_segment) if len(r_r_intervals_segment) > 0 else 0

print(f"Media de los intervalos R-R (30 segundos): {mean_rr_segment:.2f} ms")
print(f"Desviación estándar de los intervalos R-R (30 segundos): {std_rr_segment:.2f} ms")

plt.figure(figsize=(12, 6))
plt.plot(r_r_intervals_segment, label='Intervalos R-R (30 s)', color='green')
plt.title('Intervalos R-R (30 segundos)')
plt.xlabel('Número de intervalo')
plt.ylabel('Intervalo R-R (ms)')
plt.legend()
plt.grid()
plt.show()
